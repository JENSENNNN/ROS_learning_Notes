#include "ros/ros.h"
#include "header_file/hello.h"

namespace hello_ns
{
    void HelloPub::run()
    {
        ROS_INFO("自定义头文件调用");
    }
}
int main(int argc, char *argv[])
{
    setlocale(LC_ALL,"");
    ros::init(argc,argv,"hello");
    hello_ns::HelloPub hellopub;
    hellopub.run();
    return 0;
}
