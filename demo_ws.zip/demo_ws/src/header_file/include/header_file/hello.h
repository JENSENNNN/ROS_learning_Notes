#ifndef _HELLO_H
#define _HELLO_H
namespace hello_ns
{
    class HelloPub
    {
        public:
            void run();
    };
    
}

#endif 